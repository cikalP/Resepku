package com.example.resepku.CRUD.DB

data class itemDb(  val judul:String?=null,
                    val bahan2:String?=null,
                    val langkah2:String?=null,
                    val img:String?="")

