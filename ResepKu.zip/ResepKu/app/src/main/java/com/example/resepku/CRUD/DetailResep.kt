package com.example.resepku.CRUD

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.resepku.R

class DetailResep : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_resep)
    }
}